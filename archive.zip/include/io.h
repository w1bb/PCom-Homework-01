#ifndef _WI_IO_H_
#define _WI_IO_H_

#include <string.h>
#include <stdio.h>
#include "trie.h"

struct trie_node *read_rtrie(char *filename);

#endif // _WI_IO_H_
